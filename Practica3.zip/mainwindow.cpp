#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFocus();  // Establecer el foco en la ventana principal
    // Inicializar las variables
    temperatura = -1;
    voltaje = -1;
    humedad = -1;

    startTime = QDateTime::currentSecsSinceEpoch();

    // Crear el gráfico principal
    chart = new QChart();
    chart->setTitle("Gráficas combinadas");

    // Crear las series
    seriesTemp = new QLineSeries();
    seriesVolt = new QLineSeries();
    seriesHum = new QLineSeries();

    // Añadir las series al gráfico
    chart->addSeries(seriesTemp);
    chart->addSeries(seriesVolt);
    chart->addSeries(seriesHum);

    seriesTemp->setName("Temperatura (°C)");
    seriesVolt->setName("Voltaje (V)");
    seriesHum->setName("Humedad (%)");

    // Configuración del eje X (común para todas las series)
    axisX = new QValueAxis();
    axisX->setTitleText("Tiempo (s)");
    axisX->setRange(0, 40);  // Ajusta según tus datos
    chart->addAxis(axisX, Qt::AlignBottom);
    seriesTemp->attachAxis(axisX);
    seriesVolt->attachAxis(axisX);
    seriesHum->attachAxis(axisX);

    // Configuración del eje Y para Temperatura
    axisYTemp = new QValueAxis();
    axisYTemp->setTitleText("Temperatura (°C)");
    axisYTemp->setRange(0, 50);  // Ajusta según el rango de temperatura
    chart->addAxis(axisYTemp, Qt::AlignRight);
    seriesTemp->attachAxis(axisYTemp);

    // Configuración del eje Y para Voltaje
    axisYVolt = new QValueAxis();
    axisYVolt->setTitleText("Voltaje (V)");
    axisYVolt->setRange(0, 10);  // Ajusta según el rango de voltaje
    chart->addAxis(axisYVolt, Qt::AlignRight);  // Usamos el lado derecho para el voltaje
    seriesVolt->attachAxis(axisYVolt);

    // Configuración del eje Y para Humedad
    axisYHum = new QValueAxis();
    axisYHum->setTitleText("Humedad (%)");
    axisYHum->setRange(0, 100);  // Ajusta según el rango de humedad
    chart->addAxis(axisYHum, Qt::AlignRight);  // Usamos el lado derecho para la humedad
    seriesHum->attachAxis(axisYHum);

    // Configurar el QChartView
    ui->widget->setChart(chart);  // Coloca el gráfico combinado en el widget correspondiente

    db.setHostName("localhost");       // Cambia a la IP de tu servidor MySQL si no es local
    db.setDatabaseName("lecturas");   // Reemplaza con el nombre de tu base de datos
    db.setUserName("admin");         // Reemplaza con tu usuario de MySQL
    db.setPassword("changeme");      // Reemplaza con tu contraseña de MySQL
    if (!db.open()) {
        qDebug() << "Error al conectar con la base de datos:" << db.lastError().text();
    } else {
        qDebug() << "Conexión exitosa con la base de datos";
    }

    // Restante código para WebSocket y conexión...
    m_webSocket = new QWebSocket;
    m_connected = false;
    connect(m_webSocket, &QWebSocket::connected, this, &MainWindow::onConnected);
    connect(m_webSocket, &QWebSocket::disconnected, this, &MainWindow::onDisconnected);
    connect(m_webSocket, &QWebSocket::textMessageReceived, this, &MainWindow::onTextMessageReceived);
    connect(m_webSocket, &QWebSocket::errorOccurred, this, &MainWindow::onError);

    // Conectar botón de envío y activar conexión
    activarConexion();
    QTimer *cronos = new QTimer(this);
    connect(cronos, SIGNAL(timeout()), this, SLOT(sendHeartbeat()));
    connect(cronos,SIGNAL(timeout()),this,SLOT(loop()));
    cronos->start(2000);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::onDisconnected() {
    qDebug() << "WebSocket disconnected!";
    ui->textEdit->append("Desconectado del WebSocket");
    m_connected = false;  // Actualizar el estado de la conexión
}

void MainWindow::onError(QAbstractSocket::SocketError errores) {
    QString errorMsg;
    switch (errores) {
    case QAbstractSocket::HostNotFoundError:
        errorMsg = "Host no encontrado.";
        break;
    case QAbstractSocket::ConnectionRefusedError:
        errorMsg = "Conexión rechazada.";
        break;
    case QAbstractSocket::RemoteHostClosedError:
        errorMsg = "El host remoto cerró la conexión.";
        break;
    default:
        errorMsg = "Error desconocido.";
        break;
    }
    qDebug() << "Error de WebSocket: " << errorMsg;
    ui->textEdit->append("Error de WebSocket: " + errorMsg);
}

void MainWindow::connectWebSocket(const QUrl &url) {
    if (!m_connected) {
        m_webSocket->open(url);
        qDebug() << "Conectando a WebSocket en" << url;
        ui->textEdit->append("Conectando a WebSocket en: " + url.toString());
    } else {
        qDebug() << "WebSocket ya está conectado";
        ui->textEdit->append("WebSocket ya está conectado");
    }
}

void MainWindow::activarConexion() {

    if (!esp32IP.isEmpty()) {
        QUrl url(QString("ws://") + esp32IP + "/ws");
        if (!m_connected) {
            connectWebSocket(url);
        }
    } else {
        ui->textEdit->append("Error: Debes ingresar la IP y el mensaje.");
    }
}

void MainWindow::sendHeartbeat() {
    QJsonObject heartbeatMessage;
    heartbeatMessage["type"] = "heartbeat";
    heartbeatMessage["timestamp"] = QDateTime::currentSecsSinceEpoch();  // Unix timestamp

    QJsonDocument doc(heartbeatMessage);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    if (m_connected) {
        m_webSocket->sendTextMessage(jsonString);
        qDebug() << "Enviando heartbeat: " << jsonString;
    }
}

void MainWindow::onConnected() {
    qDebug() << "WebSocket connected!";
    ui->textEdit->append("Conectado a WebSocket");
    m_connected = true;  // Actualizar el estado de la conexión
}

void MainWindow::onTextMessageReceived(const QString &message) {
    qDebug() << "Mensaje recibido:" << message;  // Muestra el mensaje JSON completo recibido

    QJsonDocument doc = QJsonDocument::fromJson(message.toUtf8());
    if (!doc.isNull() && doc.isObject()) {
        QJsonObject jsonObj = doc.object();

        // Si el mensaje no contiene un timestamp, lo asigna desde Qt
        qint64 timestamp;
        if (jsonObj.contains("timestamp")) {
            timestamp = jsonObj["timestamp"].toVariant().toLongLong();
            qDebug() << "Timestamp recibido:" << timestamp;
        } else {
            timestamp = QDateTime::currentSecsSinceEpoch();  // Asigna el timestamp actual
            qDebug() << "El mensaje JSON no contiene un campo de 'timestamp', se usa timestamp actual:" << timestamp;
        }

        // Procesar temperatura
        if (jsonObj.contains("temperature")) {
            temperatura = jsonObj["temperature"].toDouble();
            qDebug() << "Temperatura recibida:" << temperatura;
            updateTemperature(temperatura, timestamp);
            ui->lcdNumber->display(temperatura);
        } else {
            qDebug() << "No se recibió campo de 'temperature' en el mensaje JSON.";
        }

        // Procesar voltaje
        if (jsonObj.contains("adc_value")) {
            voltaje = jsonObj["adc_value"].toDouble();
            qDebug() << "Voltaje recibido:" << voltaje;
            updateVoltage(voltaje, timestamp);
            ui->lcdNumber_2->display(voltaje);
        } else {
            qDebug() << "No se recibió campo de 'voltage' en el mensaje JSON.";
        }

        // Procesar humedad
        if (jsonObj.contains("humidity")) {
            humedad = jsonObj["humidity"].toDouble();
            qDebug() << "Humedad recibida:" << humedad;
            updateHumidity(humedad, timestamp);
            ui->lcdNumber_3->display(humedad);
        } else {
            qDebug() << "No se recibió campo de 'humidity' en el mensaje JSON.";
        }
    } else {
        qDebug() << "Error: mensaje JSON no válido.";
    }
}


void MainWindow::on_pushButton_clicked()
{
    enviarComando(11);
}

void MainWindow::enviarComando(int comando) {
    // Crear el objeto JSON
    QJsonObject jsonObject;
    jsonObject["type"] = "comando";  // Tipo de mensaje
    jsonObject["comando"] = comando;  // Enviar el comando como entero

    // Convertir el objeto JSON a una cadena
    QJsonDocument jsonDoc(jsonObject);
    QString jsonString = QString::fromUtf8(jsonDoc.toJson(QJsonDocument::Compact));

    // Enviar el mensaje a través del WebSocket
    m_webSocket->sendTextMessage(jsonString);
}


void MainWindow::on_pushButton_2_clicked()
{
    enviarComando(12);
}


void MainWindow::on_pushButton_3_clicked()
{
    enviarComando(13);
}

void MainWindow::enviarComandoConVelocidad(int velocidad) {
    // Crear el objeto JSON
    QJsonObject jsonObject;
    jsonObject["type"] = "comando";  // Tipo de mensaje
    jsonObject["comando"] = 5;       // Comando 5 indica que se envía la velocidad
    jsonObject["velocidad"] = velocidad;  // Añadir el valor de velocidad

    // Convertir el objeto JSON a una cadena
    QJsonDocument jsonDoc(jsonObject);
    QString jsonString = QString::fromUtf8(jsonDoc.toJson(QJsonDocument::Compact));

    // Enviar el mensaje a través del WebSocket
    m_webSocket->sendTextMessage(jsonString);
}


void MainWindow::on_pushButton_4_clicked()
{
    enviarComando(1); // Avanzar
}


void MainWindow::on_pushButton_5_clicked()
{
    enviarComando(2); // Retroceder
}


void MainWindow::on_pushButton_6_clicked()
{
    enviarComando(3); // Derecha
}


void MainWindow::on_pushButton_7_clicked()
{
    enviarComando(4); // Izquierda
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    switch(event->key()) {
    case Qt::Key_Up:
        enviarComando(1);  // Comando para avanzar
        break;
    case Qt::Key_Down:
        enviarComando(2);  // Comando para retroceder
        break;
    case Qt::Key_Left:
        enviarComando(4);  // Comando para girar a la izquierda
        break;
    case Qt::Key_Right:
        enviarComando(3);  // Comando para girar a la derecha
        break;
    default:
        QMainWindow::keyPressEvent(event);
    }
}


// Funciones de actualización (Temperatura, Voltaje, Humedad)
void MainWindow::updateTemperature(double temp, qint64 timestamp) {
    qint64 currentTime = timestamp - startTime;
    dataPointsTemp.append(QPointF(currentTime, temp));
    while (!dataPointsTemp.isEmpty() && currentTime - dataPointsTemp.first().x() > 60) {
        dataPointsTemp.removeFirst();
    }
    seriesTemp->replace(dataPointsTemp);
    axisX->setRange(currentTime - 60, currentTime);
    axisYTemp->setRange(0, 50);
}

void MainWindow::updateVoltage(double voltage, qint64 timestamp) {
    qint64 currentTime = timestamp - startTime;
    dataPointsVolt.append(QPointF(currentTime, voltage));
    while (!dataPointsVolt.isEmpty() && currentTime - dataPointsVolt.first().x() > 60) {
        dataPointsVolt.removeFirst();
    }
    seriesVolt->replace(dataPointsVolt);
    axisX->setRange(currentTime - 60, currentTime);
    axisYVolt->setRange(0, 10);
}

void MainWindow::updateHumidity(double humidity, qint64 timestamp) {
    qint64 currentTime = timestamp - startTime;
    dataPointsHum.append(QPointF(currentTime, humidity));
    while (!dataPointsHum.isEmpty() && currentTime - dataPointsHum.first().x() > 60) {
        dataPointsHum.removeFirst();
    }
    seriesHum->replace(dataPointsHum);
    axisX->setRange(currentTime - 60, currentTime);
    axisYHum->setRange(0, 100);
}

void MainWindow::loop(){
    // Verificar si los datos fueron recibidos correctamente
    if (temperatura != -1 && voltaje != -1 && humedad != -1) {
        // Insertar los datos en la base de datos
        insertarDatos(temperatura, voltaje, humedad);
    } else {
        qDebug() << "No se han recibido todos los datos necesarios.";
    }
}

bool MainWindow::insertarDatos(double temperatura, double voltaje, double humedad) {
    // Obtener el timestamp en formato epoch (segundos desde 1970)
    qint64 timestamp = QDateTime::currentSecsSinceEpoch();

    // Crear la consulta SQL para insertar datos (temperatura, voltaje y humedad)
    QSqlQuery query;
    query.prepare("INSERT INTO id (timestamp, temperatura, voltaje, humedad) VALUES (:timestamp, :temperatura, :voltaje, :humedad)");

    // Asignar los valores a los placeholders
    query.bindValue(":timestamp", timestamp);
    query.bindValue(":temperatura", temperatura);
    query.bindValue(":humedad", humedad);
    query.bindValue(":voltaje", voltaje);

    // Ejecutar la consulta e imprimir el resultado
    if (!query.exec()) {
        qDebug() << "Error al insertar en la tabla ejemplo1:" << query.lastError().text();
        return false;  // Si hubo un error, regresa false
    }

    qDebug() << "Datos insertados exitosamente en ejemplo1:"
             << "Timestamp:" << timestamp
             << ", Temperatura:" << temperatura
             << ", Voltaje:" << voltaje
             << ", Humedad:" << humedad;
    return true;  // Regresa true si la inserción fue exitosa
}
